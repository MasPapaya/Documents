tinyMCE.addI18n('en.jbimages',{
	desc : 'Upload an image'
});
