tinyMCE.addI18n('es.jbimages',{
	desc : 'Subir una imagen'
});