tinyMCE.addI18n('es.jbimages_dlg',{
    title : 'Subir una imagen desde el computador',
    select_an_image : 'Seleccione una imagen',
    upload_in_progress : 'cargando',
    upload_complete : 'carga completa',
    upload : 'Subir',
    longer_than_usual : 'Esto está llevando más tiempo de lo habitual.',
    maybe_an_error : 'Un error ha ocurrido',
    view_output : 'Ver script\'s de salida ',
    lang_id : 'english' /* php-side language files are in: ci/application/language/{lang_id}; and in ci/system/language/{lang_id} */
});
